package org.jeecgframework.web.system.controller.core;

import javax.naming.Context;
import javax.naming.ldap.InitialLdapContext;
import javax.naming.ldap.LdapContext;
import java.util.Hashtable;

/**
 * Created by admPPMSd on 10/16/2018.
 */
public class LDAPSConnectionsV {

    public  void connectLDAPs(){
        String URL = "ldaps://singaporepower.local:636/dc=singaporepower,dc=local";
        String FACTORY = "com.sun.jndi.ldap.LdapCtxFactory";
        LdapContext ctx = null;

        String path = "F:\\CertKeyStore\\SPCert.jks"; //jks cert file path
//        System.setProperty("javax.net.ssl.trustStore", path);
//        System.setProperty("javax.net.ssl.trustStorePassword","NARI_$123");
        System.setProperty("javax.net.debug", "all");

        Hashtable<String, String> env = new Hashtable<String, String>();

        env.put(Context.INITIAL_CONTEXT_FACTORY, FACTORY);
        env.put(Context.PROVIDER_URL, URL);
        env.put(Context.SECURITY_AUTHENTICATION, "simple");
        env.put(Context.SECURITY_PRINCIPAL, "Sap\\ldapPPMSd"); // login ldap account
        env.put(Context.SECURITY_CREDENTIALS, "Welcome@19"); // password
        env.put(Context.SECURITY_PROTOCOL,"ssl");
        env.put(Context.REFERRAL,"ignore");
        env.put("java.naming.ldap.factory.socket","org.jeecgframework.web.system.controller.core.MySSLSocketFactory"); //package+className

        try {
            ctx = new InitialLdapContext(env, null);
            System.out.println( "LDAPS connection... success." );
        } catch (javax.naming.AuthenticationException e) {
            System.out.println("LDAPS connect... failure.");
            e.printStackTrace();
        } catch (Exception e) {
            System.out.println("LDAPS connect...error.");
            e.printStackTrace();
        }
    }

    public static void main(String[] args){
        LDAPSConnectionsV connections = new LDAPSConnectionsV();
        connections.connectLDAPs();
    }
}
