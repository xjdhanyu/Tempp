package org.jeecgframework.web.system.controller.core;

import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.security.KeyManagementException;
import java.security.KeyStore;
import java.security.KeyStoreException;
import java.security.NoSuchAlgorithmException;
import java.security.SecureRandom;
import java.security.UnrecoverableKeyException;
import java.security.cert.CertificateException;
import java.util.Date;
import java.util.Hashtable;

import javax.naming.Context;
import javax.naming.ldap.InitialLdapContext;
import javax.naming.ldap.LdapContext;
import javax.net.ssl.KeyManagerFactory;
import javax.net.ssl.SSLContext;
import javax.net.ssl.SSLSocket;
import javax.net.ssl.SSLSocketFactory;
import javax.net.ssl.TrustManagerFactory;

/**
 * Created by admPPMSd on 10/17/2018.
 */
public class LdapUtil {
    public static void main(String[] args) throws NoSuchAlgorithmException, KeyStoreException, UnrecoverableKeyException, CertificateException, FileNotFoundException, IOException, KeyManagementException {
        System.setProperty("javax.net.debug", "all");

        TrustManagerFactory tf = null;

        KeyManagerFactory kf = KeyManagerFactory.getInstance("SunX509");
        KeyStore ks = KeyStore.getInstance("JKS");
        ks.load(new FileInputStream("F:\\CertKeyStore\\SPCert.jks"), "NARI_$123".toCharArray());
        kf.init(ks, "NARI_$123".toCharArray());
        tf = TrustManagerFactory.getInstance("SunX509");
        tf.init(ks);

        SSLContext sc = SSLContext.getInstance("TLSv1.2");

        sc.init(kf.getKeyManagers(), tf.getTrustManagers(), SecureRandom.getInstanceStrong());

        SSLContext.setDefault(sc);

        String URL = "ldaps://singaporepower.local:636/dc=singaporepower,dc=local";
        String FACTORY = "com.sun.jndi.ldap.LdapCtxFactory";
        LdapContext ctx = null;

        Hashtable<String, String> env = new Hashtable<String, String>();

        env.put(Context.INITIAL_CONTEXT_FACTORY, FACTORY);
        env.put(Context.PROVIDER_URL, URL);
        env.put(Context.SECURITY_AUTHENTICATION, "simple");
        env.put(Context.SECURITY_PRINCIPAL, "Sap\\ldapPPMSd"); // login ldap account
        env.put(Context.SECURITY_CREDENTIALS, "Welcome@19"); // password
        env.put("com.sun.jndi.connection.timecout","300000");
//        env.put(Context.SECURITY_PROTOCOL,"ssl");
//        env.put(Context.REFERRAL,"ignore");
//        env.put("java.naming.ldap.factory.socket","org.jeecgframework.web.system.controller.core.MySSLSocketFactory"); //package+className

        try {
            ctx = new InitialLdapContext(env, null);
            System.out.println( "LDAPS connection... success." );
        } catch (javax.naming.AuthenticationException e) {
            System.out.println("LDAPS connect... failure.");
            e.printStackTrace();
        } catch (Exception e) {
            System.out.println("LDAPS connect...error.");
            e.printStackTrace();
        }
    }
}
